<br>
<br>
<centre>
    <table>
        <tr><th colspan="2" class="table_header">Registration Form</th></tr>
        <tr><th>Full Name</th><td><?= $fname ?? ''; ?></td></tr>
        <tr><th>Email</th><td><?= $email ?? ''; ?></td></tr>
        <tr><th>Mobile</th><td><?= $mob ?? ''; ?></td></tr>
        <tr><th>Date of Birth</th><td><?= $dob ?? ''; ?></td></tr>
    </table>
</centre>