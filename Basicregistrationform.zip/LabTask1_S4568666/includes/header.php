<html>
    <head>
        <title>Registration form</title>
        <link href="css/styles.css" rel="stylesheet" type="text/css"/>
    </head>
    <body>
