<br>
<br>
<form action="index.php" method="post" novalidate="true">
    <div class="box"><h1>Registration form</h1></div>
    
    <fieldset>
        <label>Full Name:  
        <small class="error">
            <?=$errors['fname']??'';?>
        </small>
        </label>
        <input type="text" name="fname" maxlength="30" value="<?=$fname??'';?>"/>

        <br><br>

        <label>Email
        <small class="error">
            <?=$errors['email']??'';?>
        </small>
        </label>  
        <input type="text" name="email" value="<?=$email??'';?>"/>
        
        <br><br>

        <label>Mobile:  
        <small class="error">
            <?=$errors['mob']??'';?>
        </small>
        </label> 
        <input type="text" name="mob" maxlength="10" value="<?=$mob??'';?>"/>
        
        <br><br>
        
        <label>Date of Birth:  
        <small class="error">
            <?=$errors['dob']??'';?>
        </small>
        </label> 
        <input type="date" name="dob" maxlength="30" value="<?=$dob??'';?>"/>
       <button type="submit" name="submit">Submit</button>  
    </fieldset>
    </form>
