<?php

include_once 'includes/header.php';
include 'includes/validation_functions.php';

$errors = [];
if (isset($_POST['submit'])) {
        
    if (isset($_POST['fname'])) {
            $fname = trim($_POST['fname'] ?? '');
            if (strlen($fname) == 0) {
                $errors['fname'] = "missing full name!";
            } else {
            $temp = str_replace(' ','',$fname);
            if (!ctype_alpha($temp)) {
            $errors['fname'] = 'Enter alpha and spaces characters only';
        }
    }
        }

        if (isset($_POST['mob'])) {
        $mob = trim($_POST['mob']);
        if (strlen($mob) == 0) {
            $errors['mob'] = 'Enter your mob';
        } elseif (!ctype_digit($mob)) {
            $errors['mob'] = 'Enter a valid mobile number';
        } elseif (strlen($mob) != 10) {
            $errors['mob'] = 'Must be atleast 10 digits long';
        }
    }

        if (isset($_POST['email'])) {
            $email = trim($_POST['email'] ?? '');
            if (strlen($email) == 0) {
                $errors['email'] = "missing Email address!!";
            } else if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
                $errors['email'] = "Please enter a real email address!";
            }
        }
        if (isset($_POST['dob'])) {
        $dob = trim($_POST['dob']);
        if (strlen($dob) == 0) {
            $errors['dob'] = 'Enter your Date of Birth';
        } elseif (!validateDOB($dob)) {
            $errors['dob'] = 'Enter a valid Date of Birth';
        }
    }
        
     //ends checking data
        if (count($errors) == 0) {
        include_once 'includes/display_data.php';
    } else {
        include_once 'includes/registration_form.php';
    }
} else {
    include_once 'includes/registration_form.php';
}

include_once 'includes/footer.php';
