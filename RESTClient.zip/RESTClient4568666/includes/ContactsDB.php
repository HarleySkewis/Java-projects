<?php

class ContactsDB {

    var $pdo;

    public function __construct() {
        $this->pdo = new PDO('mysql:host=localhost;dbname=contactsdb', 'root', '');
    }

    function addContact($values) {
        $sql = "insert into contacts
            (first_name, last_name, email, mobile, filename)
            values
            (?,?,?,?,?)";
        $statement = $this->pdo->prepare($sql);
        $success = $statement->execute($values);

        return $success;
    }

    function getContacts() {
        $sql = "select * from contacts";
        $statement = $this->pdo->query($sql);
        $statement->setFetchMode(PDO::FETCH_ASSOC);
        $records = $statement->fetchAll();

        return $records;
    }

    function searchContacts($keyword) {
        $sql = "select * from contacts where
            id like '%$keyword%'
            or first_name like '%$keyword%'
            or last_name like '%$keyword%'
            or email like '%$keyword%'
            or mobile like '%$keyword%'
            or filename like '%$keyword'";
        $statement = $this->pdo->query($sql);
        $statement->setFetchMode(PDO::FETCH_ASSOC);
        $records = $statement->fetchAll();

        return $records;
    }

}
