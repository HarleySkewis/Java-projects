<?php

class MountainsDB {

    var $pdo;

    public function __construct() {
        $this->pdo = new PDO('mysql:host=localhost;dbname=emountainsdb', 'root', '');
    }

    function addMountain($values) {
        $sql = "insert into mountains
            (name, location, city, country, height, filename)
            values
            (?,?,?,?,?,?)";
        $statement = $this->pdo->prepare($sql);
        $success = $statement->execute($values);

        return $success;
    }

    function getMountains() {
        $sql = "select * from mountains";
        $statement = $this->pdo->query($sql);
        $statement->setFetchMode(PDO::FETCH_ASSOC);
        $records = $statement->fetchAll();

        return $records;
    }

    function searchMountains($keyword) {
        $sql = "select * from mountains where
            id like '%$keyword%'
            or name like '%$keyword%'
            or location like '%$keyword%'
            or city like '%$keyword%'
            or country like '%$keyword%'
            or height like '%$keyword'
            or filename like '%$keyword'";
        $statement = $this->pdo->query($sql);
        $statement->setFetchMode(PDO::FETCH_ASSOC);
        $records = $statement->fetchAll();

        return $records;
    }

}