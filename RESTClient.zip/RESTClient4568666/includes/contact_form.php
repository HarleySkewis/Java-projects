<br>
<br>
<div class="container">
    <div class="row">
        <div class="col-md-3"></div>
        <div class="col-md-6 box-blue text-center">Contacts Form</div>
        <div class="col-md-3"></div>
    </div>
    <div class="row">
        <div class="col-md-3"></div>
        <div class="col-md-6 jumbotron">
            <form class="form-horizontal" action="" method="post" novalidate="">
                
                <div class="form-group">
                    <label class="control-label">Contact Name</label>
                    <input ckass="form-control" type="text" name="name" maxlength="30" />
                </div>
                
                <div class="form-group">
                    <label class="control-label">Contact Email</label>
                    <input ckass="form-control" type="text" name="email" maxlength="30" />
                </div>
                
                <div class="form-group">
                    <label class="control-label">Contact Mobile</label>
                    <input ckass="form-control" type="text" name="mobile" maxlength="30" />
                </div>
                
                <div class="form-group">
                    <label class="control-label">Photo Filename</label>
                    <input ckass="form-control" type="text" name="filename" maxlength="30" />
                </div>
                <br>
                <div class="form-group">
                    <button class="btn btn-clue btn-block" type="submit" name="submit" >Submit</button>
                </div>
            </form>
        </div>
        <div class="col-md-3"></div>
    </div>
</div>