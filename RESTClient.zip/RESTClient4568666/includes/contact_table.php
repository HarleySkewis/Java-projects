<div class="container">
    <div class="row">
        <div class="col-md-2"></div>
        <div class="col-md-8 box-blue text-center">Contact Table</div>
        <div class="col-md-2"></div>
    </div>
    <div class="row">
        <div class="col-md-2"></div>
        <div class="col-md-8 jumbotron text-center">
            <div class="table-responsive">
                <table class="table table-striped table-hover">
                    <tr>
                        <th>Full Name</th>
                        <th>Contact Email</th>
                        <th>Contact Mobile</th>
                        <th>Photo Filename</th>
                    </tr>
                    <tr>
                        <th><?= $name ?? ''; ?></th>
                        <th><?= $email ?? ''; ?></th>
                        <th><?= $mobile ?? ''; ?></th>
                        <th><?= $filename ?? ''; ?></th>
                    </tr>
                </table>
            </div>
        </div>
        <div class="col-md-2"></div>
    </div>
</div>

