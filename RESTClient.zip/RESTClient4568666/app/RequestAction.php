<?php

require __DIR__ . '/../vendor/autoload.php';

use GuzzleHttp\Client;
use Twig\Environment;
use Twig\Loader\FilesystemLoader;

class RequestAction {

    var $client;

    function __construct() {
        //$this->client = new Client(['base_uri' => 'http://localhost/RESTServer4568666/']);
        $this->client = new Client(['base_uri' => 'http://35.153.128.83/RESTServer4568666/']);
        $loader = new FilesystemLoader(__DIR__ . '/../templates');
        $this->view = new Environment($loader);
    }

    function index() {

        echo $this->view->render('index.twig');
    }

    function getMountain() {
        $uri = 'mountains';
        $response = $this->client->get($uri);
        $contents = $response->getBody()->getContents();
        $records = GuzzleHttp\json_decode($contents, true);

        echo $this->view->render('mountain_table.twig', ['records' => $records]);
    }

    function addMountain() {
        if (isset($_POST['submit'])) {

            $filename = $_FILES['image']['name'];
            $temp_file = $_FILES['image']['tmp_name'];
            $error_level = $_FILES['image']['error'];

            $destination = 'static/assets/photos/';
            $target_file = $destination . $filename;

            move_uploaded_file($temp_file, $target_file);

            $_POST['filename'] = $filename;

            $uri = 'mountains';
            $response = $this->client->request('POST', $uri, ['form_params' => $_POST]);
            $contents = $response->getBody()->getContents();
            $data = json_decode($contents, true);
            $message = $data['message'];
            echo $this->view->render('message.twig', ['message' => $message]);
        } else {
            echo $this->view->render('mountain_form.twig');
        }
    }

    function searchMountains(){
        if (isset($_POST['submit'])) {
            $keyword = $_POST['keyword'];
            
            $uri = "mountains/keyword/$keyword";
            $response = $this->client->get($uri);
            $contents = $response->getBody()->getContents();
            $records = json_decode($contents, true);

            echo $this->view->render('mountain_table.twig', ['records' => $records]);
        } else {
            echo $this->view->render('search_form.twig');
            
        }
    }

}
