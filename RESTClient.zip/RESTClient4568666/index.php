<?php

include_once 'app/RequestAction.php';

$requestAction = new RequestAction();

if (isset($_GET['action'])) {

    $action = $_GET['action'];

    if ($action == 'addMountain') {

        $requestAction->addMountain();
        
    } elseif ($action == 'getMountains') {

        $requestAction->getMountain();
        
    } elseif ($action == 'searchMountains') {
        
        $requestAction->searchMountains();
    }
  }else{
    $requestAction->index();
}

