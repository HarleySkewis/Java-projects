<?php

include_once 'config.php';
include_once 'includes/MountainsDB.php';

if (isset($_GET['action'])) {

    $action = $_GET['action'];

    if ($action == 'addMountain') {

        if (isset($_POST['submit'])) {
            
            foreach ($_POST as $key => $value){
                ${$key} = $value;
            }
            $records = [$name, $location, $city, $country, $height, $filename];

            $mountains = new MountainsDB();
            $success = $mountains = addMountain($values);

            header("location:?action=getMountains");
        } else {

            echo $view->render('mountain_form.twig');
        }
    } elseif ($action == 'getMountains') {

        $mountains = new MountainsDB();
        $records = $mountains->getMountains();

        echo $view->render('mountain_table.twig', ['records' => $records]);
        
    } elseif ($action == 'searchMountains') {
        if (isset($_POST['keyword'])) {
            
            $keyword = $_POST['keyword'];
            $mountains = new MountainsDB();
            $records = $mountains->searchMountains($keyword);

            echo $view->render('mountain_table.twig', ['records' => $records]);
        }
        echo $view->render('search_form.twig');
    }
} else {
    echo $view->render('index.twig');
}

