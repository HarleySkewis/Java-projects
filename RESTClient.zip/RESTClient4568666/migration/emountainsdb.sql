-- phpMyAdmin SQL Dump
-- version 4.9.0.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Oct 27, 2019 at 12:34 PM
-- Server version: 10.3.16-MariaDB
-- PHP Version: 7.3.7




--
-- Database: `emountainsdb`
--

CREATE DATABASE IF NOT EXISTS `emountainsdb` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `emountainsdb`;
-- --------------------------------------------------------

--
-- Table structure for table `mountains`
--

CREATE TABLE `mountains` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `location` varchar(100) NOT NULL,
  `city` varchar(100) NOT NULL,
  `country` varchar(100) NOT NULL,
  `height` int(11) NOT NULL,
  `filename` varchar(100) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `mountains`
--

INSERT INTO `mountains` (`id`, `name`, `location`, `city`, `country`, `height`, `filename`) VALUES
(1, 'Everest', 'Himalayas', 'Kathmandu', 'Nepal', 8848, 'mountain1.jpg'),
(2, 'K2', 'Baltistan Himalayas', 'Askole', 'Pakistan', 8611, 'mountain2.jpg'),
(3, 'Mckinley', 'Denali National Park and Preserve', 'Denali', 'Alaska', 6190, 'mountain3.jpg'),
(4, 'Aconcagua', 'Principal Cordillera Andes', 'Mendoza', 'Argentina', 6692, 'mountain4.jpg'),
(5, 'Mont Blanc', 'Aosta Valley Haute Savoie', 'Courmayeur and Chamonix', 'Borders France Italy', 4696, 'mountain5.jpg'),
(6, 'Mount Cook', 'Aoraki National Park', 'Mount Cook Village', 'New Zealand', 3724, 'mountain6.jpg');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `mountains`
--
ALTER TABLE `mountains`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `mountains`
--
ALTER TABLE `mountains`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
COMMIT;

