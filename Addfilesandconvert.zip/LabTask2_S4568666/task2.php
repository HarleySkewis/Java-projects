<?php

$pdo = new PDO("mysql:host=localhost;dbname=emountainsdb","root","");

$sql = "insert into mountains";

$statement = $pdo->query($sql);

$statement->setFetchMode(PDO::FETCH_ASSOC);

$records = $statement->fetchAll();

$f12 = fopen('dbtocsv.csv', 'w');
foreach($records as $record){
    $line = [];
    foreach($record as $key => $value ){
        $line[]=$value;
    }
    fputcsv($f12, $line);
}

fclose($f12);