<?php

$pdo = new PDO("mysql:host=localhost;dbname=emountainsdb","root","");

$sql = "select * from mountains";

$statement = $pdo->query($sql);

$statement->setFetchMode(PDO::FETCH_ASSOC);

$records = $statement->fetchAll();

$json_data = json_encode($records);

$f9 = fopen("dbtojson.json", "w");
fwrite($f9, $json_data);
fclose($f9);