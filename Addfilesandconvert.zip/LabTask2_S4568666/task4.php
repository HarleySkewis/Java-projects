<?php

$pdo = new PDO("mysql:host=localhost;dbname=emountainsdb","root","");

$write = fopen('csvtodb.csv','r');
while(!feof($write)){
    $data = fgetcsv($write);
    }
fclose($write);

$sql = "insert into mountains (name, location, city, country, height, filename)"
        . "values(:name,:location,:city,:country,:height,:filename)";

$statement = $pdo->prepare($sql);

$name = $data[0]; 
$location = $data[1];
$city = $data[2];
$country = $data[3];
$height = $data[4];
$filename = $data[5];

$statement->bindParam( ":name" , $name);
$statement->bindParam( ":location" , $location);
$statement->bindParam( ":city" , $city);        
$statement->bindParam( ":country" , $country);
$statement->bindParam( ":height" , $height);
$statement->bindParam( ":filename" , $filename);

$success = $statement->execute();