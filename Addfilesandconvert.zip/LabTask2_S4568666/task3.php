<?php

$pdo = new PDO("mysql:host=localhost;dbname=emountainsdb","root","");

$f10 = fopen("jsontodb.json", "r");
$info = fread($f10, filesize("jsontodb.json"));

$json_data = json_decode($info, true);


$sql = "insert into mountains (name, location, city, country, height, filename)"
        . "values(:name,:location,:city,:country,:height,:filename)";

$statement = $pdo->prepare($sql);

$name = $json_data['name']; 
$location = $json_data['location'];
$city = $json_data['city'];
$country = $json_data['country'];
$height = $json_data['height'];
$filename = $json_data['filename'];

$statement->bindParam( ":name" , $name);
$statement->bindParam( ":location" , $location);
$statement->bindParam( ":city" , $city);        
$statement->bindParam( ":country" , $country);
$statement->bindParam( ":height" , $height);
$statement->bindParam( ":filename" , $filename);

$success = $statement->execute($json_data);